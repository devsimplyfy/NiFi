package iww.processors.dynamo;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.AmazonServiceException.ErrorType;

/**
 * Provides reused elements and utilities for the AWS DynamoDB related tests
 *
 * @see GetDynamoDB2Test
 * @see PutDynamoDBColumnWiseTest
 * @see DeleteDynamoDB2Test
 */
public abstract class AbstractDynamoDBTest {

    protected AmazonServiceException getSampleAwsServiceException() {
        final AmazonServiceException testServiceException = new AmazonServiceException("Test AWS Service Exception");
        testServiceException.setErrorCode("8673509");
        testServiceException.setErrorMessage("This request cannot be serviced right now.");
        testServiceException.setErrorType(ErrorType.Service);
        testServiceException.setServiceName("Dynamo DB");
        testServiceException.setRequestId("TestRequestId-1234567890");

        return testServiceException;
    }
}
