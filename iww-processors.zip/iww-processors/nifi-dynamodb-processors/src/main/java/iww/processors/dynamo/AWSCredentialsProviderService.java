package iww.processors.dynamo;

import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.annotation.documentation.Tags;
import org.apache.nifi.controller.ControllerService;
import org.apache.nifi.processor.exception.ProcessException;

import com.amazonaws.auth.AWSCredentialsProvider;

/**
 * AWSCredentialsProviderService interface to support getting AWSCredentialsProvider used for instantiating
 * aws clients
 *
 * @see <a href="http://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/auth/AWSCredentialsProvider.html">AWSCredentialsProvider</a>
 */
@Tags({"aws", "security", "credentials", "provider", "session"})
@CapabilityDescription("Provides AWSCredentialsProvider.")
public interface AWSCredentialsProviderService extends ControllerService {

    /**
     * Get credentials provider
     * @return credentials provider
     * @throws ProcessException process exception in case there is problem in getting credentials provider
     *
     * @see  <a href="http://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/auth/AWSCredentialsProvider.html">AWSCredentialsProvider</a>
     */
    AWSCredentialsProvider getCredentialsProvider() throws ProcessException;
}
