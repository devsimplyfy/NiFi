package iww.processors.dynamo;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Utility class to keep a map of keys and flow files
 */
class ItemKeys {

    protected Object hashKey = "";
    protected Object rangeKey = "";

    public ItemKeys(Object hashKey, Object rangeKey) {
        if ( hashKey != null )
            this.hashKey = hashKey;
        if ( rangeKey != null )
            this.rangeKey = rangeKey;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this,ToStringStyle.SHORT_PREFIX_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other, false);
    }
}
