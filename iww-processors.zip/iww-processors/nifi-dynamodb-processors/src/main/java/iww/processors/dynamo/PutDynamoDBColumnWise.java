package iww.processors.dynamo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.nifi.annotation.behavior.SystemResourceConsideration;
import org.apache.nifi.annotation.behavior.InputRequirement;
import org.apache.nifi.annotation.behavior.ReadsAttribute;
import org.apache.nifi.annotation.behavior.ReadsAttributes;
import org.apache.nifi.annotation.behavior.InputRequirement.Requirement;
import org.apache.nifi.annotation.behavior.SupportsBatching;
import org.apache.nifi.annotation.behavior.SystemResource;
import org.apache.nifi.annotation.behavior.WritesAttribute;
import org.apache.nifi.annotation.behavior.WritesAttributes;
import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.annotation.documentation.SeeAlso;
import org.apache.nifi.annotation.documentation.Tags;
import org.apache.nifi.components.PropertyDescriptor;
import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.ProcessContext;
import org.apache.nifi.processor.ProcessSession;
import org.apache.nifi.processor.Relationship;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.document.BatchWriteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.BatchWriteItemRequest;
import com.amazonaws.services.dynamodbv2.model.BatchWriteItemResult;
import com.amazonaws.services.dynamodbv2.model.PutRequest;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;

@SupportsBatching
@SeeAlso({ DeleteDynamoDB2.class, GetDynamoDB2.class })
@InputRequirement(Requirement.INPUT_REQUIRED)
@Tags({ "Amazon", "DynamoDB", "AWS", "Put", "Insert" })
@CapabilityDescription("Puts a document from DynamoDB based on hash and range key.  The table can have either hash and range or hash key alone."
		+ " Currently the keys supported are string and number and value can be json document. "
		+ "In case of hash and range keys both key are required for the operation."
		+ " The FlowFile content must be JSON. FlowFile content is mapped to the specified Json Document attribute in the DynamoDB item.")
@WritesAttributes({
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_KEY_ERROR_UNPROCESSED, description = "Dynamo db unprocessed keys"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_RANGE_KEY_VALUE_ERROR, description = "Dynamod db range key error"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_KEY_ERROR_NOT_FOUND, description = "Dynamo db key not found"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_EXCEPTION_MESSAGE, description = "Dynamo db exception message"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_CODE, description = "Dynamo db error code"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_MESSAGE, description = "Dynamo db error message"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_TYPE, description = "Dynamo db error type"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_SERVICE, description = "Dynamo db error service"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_RETRYABLE, description = "Dynamo db error is retryable"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_REQUEST_ID, description = "Dynamo db error request id"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ERROR_STATUS_CODE, description = "Dynamo db error status code"),
		@WritesAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ITEM_IO_ERROR, description = "IO exception message on creating item") })
@ReadsAttributes({
		@ReadsAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ITEM_HASH_KEY_VALUE, description = "Items hash key value"),
		@ReadsAttribute(attribute = AbstractDynamoDBProcessor.DYNAMODB_ITEM_RANGE_KEY_VALUE, description = "Items range key value") })
@SystemResourceConsideration(resource = SystemResource.MEMORY)
public class PutDynamoDBColumnWise extends AbstractWriteDynamoDBProcessor {

	/*
	 * public static final Relationship REL_SUCCESS = new
	 * Relationship.Builder().name("success")
	 * .description("FlowFiles are routed to success relationship").build(); public
	 * static final Relationship REL_FAILURE = new
	 * Relationship.Builder().name("failure")
	 * .description("FlowFiles are routed to failure relationship").build(); public
	 * static final PropertyDescriptor CREDENTIALS_FILE =
	 * CredentialPropertyDescriptors.CREDENTIALS_FILE; public static final
	 * PropertyDescriptor ACCESS_KEY = CredentialPropertyDescriptors.ACCESS_KEY;
	 * public static final PropertyDescriptor SECRET_KEY =
	 * CredentialPropertyDescriptors.SECRET_KEY;
	 */
	public static final List<PropertyDescriptor> properties = Collections.unmodifiableList(
			Arrays.asList(TABLE, HASH_KEY_NAME, RANGE_KEY_NAME, HASH_KEY_VALUE, RANGE_KEY_VALUE, HASH_KEY_VALUE_TYPE,
					RANGE_KEY_VALUE_TYPE, JSON_DOCUMENT, DOCUMENT_CHARSET, BATCH_SIZE, REGION, ACCESS_KEY, SECRET_KEY,
					CREDENTIALS_FILE, AWS_CREDENTIALS_PROVIDER_SERVICE, TIMEOUT, SSL_CONTEXT_SERVICE,
					PROXY_CONFIGURATION_SERVICE, PROXY_HOST, PROXY_HOST_PORT, PROXY_USERNAME, PROXY_PASSWORD));

	/**
	 * Dyamodb max item size limit 400 kb
	 */
	public static final int DYNAMODB_MAX_ITEM_SIZE = 400 * 1024;

	@Override
	protected List<PropertyDescriptor> getSupportedPropertyDescriptors() {
		return properties;
	}

	@Override
	public void onTrigger(final ProcessContext context, final ProcessSession session) {
		List<FlowFile> flowFiles = session
				.get(context.getProperty(BATCH_SIZE).evaluateAttributeExpressions().asInteger());
		if (flowFiles == null || flowFiles.size() == 0) {
			return;
		}

		Map<ItemKeys, FlowFile> keysToFlowFileMap = new HashMap<>();

		final String table = context.getProperty(TABLE).evaluateAttributeExpressions().getValue();

		final String hashKeyName = context.getProperty(HASH_KEY_NAME).evaluateAttributeExpressions().getValue();
		final String hashKeyValueType = context.getProperty(HASH_KEY_VALUE_TYPE).getValue();
		final String rangeKeyName = context.getProperty(RANGE_KEY_NAME).evaluateAttributeExpressions().getValue();
		final String rangeKeyValueType = context.getProperty(RANGE_KEY_VALUE_TYPE).getValue();
		final String jsonDocument = context.getProperty(JSON_DOCUMENT).evaluateAttributeExpressions().getValue();
		final String charset = context.getProperty(DOCUMENT_CHARSET).evaluateAttributeExpressions().getValue();

		TableWriteItems tableWriteItems = new TableWriteItems(table);

		for (FlowFile flowFile : flowFiles) {
			final Object hashKeyValue = getValue(context, HASH_KEY_VALUE_TYPE, HASH_KEY_VALUE, flowFile);
			final Object rangeKeyValue = getValue(context, RANGE_KEY_VALUE_TYPE, RANGE_KEY_VALUE, flowFile);

			if (!isHashKeyValueConsistent(hashKeyName, hashKeyValue, session, flowFile)) {
				continue;
			}

			if (!isRangeKeyValueConsistent(rangeKeyName, rangeKeyValue, session, flowFile)) {
				continue;
			}

			if (!isDataValid(flowFile, jsonDocument)) {
				flowFile = session.putAttribute(flowFile, AWS_DYNAMO_DB_ITEM_SIZE_ERROR,
						"Max size of item + attribute should be 400kb but was " + flowFile.getSize()
								+ jsonDocument.length());
				session.transfer(flowFile, REL_FAILURE);
				continue;
			}

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			session.exportTo(flowFile, baos);

			byte a[] = baos.toByteArray();
			StringBuffer sb = new StringBuffer();
	

			for (int i = 0; i < a.length; i++) {
				sb.append((char) a[i]);
			}

			JSONObject jobj = new JSONObject();
			try {
				Object obj = new JSONParser().parse(sb.toString());
				jobj = (JSONObject) obj;
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Map<String, Object> data = jsonToMap(jobj);
			if (rangeKeyValue == null || StringUtils.isBlank(rangeKeyValue.toString())) {
				//tableWriteItems.addItemToPut(new Item().withKeyComponent(hashKeyName, hashKeyValue)
				//		.withJSON(jsonDocument, IOUtils.toString(baos.toByteArray(), charset)));
				// tableWriteItems.
				/*
				 * Map<String, List<WriteRequest>> requestItems = new HashMap<>();
				 * List<WriteRequest> writeRequests = new ArrayList<>();
				 * 
				 * data.forEach((key, value) -> { Map<String, AttributeValue> item =
				 * newItem(partitionKeyValue, key, value); PutRequest putRequest = new
				 * PutRequest(item); WriteRequest writeRequest = new WriteRequest(putRequest);
				 * 
				 * writeRequests.add(writeRequest); });
				 * 
				 * requestItems.put(table, writeRequests); BatchWriteItemRequest
				 * batchWriteItemRequest = new BatchWriteItemRequest(requestItems);
				 * 
				 * BatchWriteItemResult batchWriteItemResult =
				 * dynamoDB.batchWriteItem(batchWriteItemRequest); BatchWriteItemOutcome outcome
				 * = new BatchWriteItemOutcome(batchWriteItemResult);
				 */

				/*
				 * do { // Check for unprocessed keys which could happen if you exceed //
				 * provisioned throughput
				 * 
				 * Map<String, List<WriteRequest>> unprocessedItems =
				 * outcome.getUnprocessedItems();
				 * 
				 * if (outcome.getUnprocessedItems().size() == 0) {
				 * logger.debug("No unprocessed items found"); } else {
				 * logger.debug("Retrieving the unprocessed items"); outcome =
				 * DynamoManager.getDynamo().batchWriteItemUnprocessed(unprocessedItems); }
				 * 
				 * } while (outcome.getUnprocessedItems().size() > 0);
				 */

				// For Update
				Map<String, Object> dataMap = jsonToMap(jobj);
				StringBuilder sbl = new StringBuilder("set");
				NameMap nameMap = new NameMap();
				ValueMap valueMap = new ValueMap();
				Set<String> keys = dataMap.keySet();
				Iterator<String> iterator = keys.iterator();

				for (int i = 0; i < dataMap.size(); i++) {
					String key = iterator.next();
					// create update expression:
					sbl.append(" #key" + i + "=:val" + i);
					// create name Map
					nameMap.with("#key" + i, key);
					// create value map
					valueMap.with(":val" + i, dataMap.get(key));

					if (i != dataMap.size() - 1) {
						sbl.append(",");
					}
				}

				UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey(hashKeyName, hashKeyValue)
						.withUpdateExpression(sbl.toString()).withNameMap(nameMap).withValueMap(valueMap)
						.withReturnValues(ReturnValue.ALL_NEW);
				final DynamoDB dynamoDB2 = getDynamoDB();
				UpdateItemOutcome outcome = dynamoDB2.getTable(table).updateItem(updateItemSpec);
				outcome.getItem().toJSONPretty();
				// Update Spec till here

			} else {
				/*tableWriteItems.addItemToPut(new Item().withKeyComponent(hashKeyName, hashKeyValue)
						.withKeyComponent(rangeKeyName, rangeKeyValue)
						.withJSON(jsonDocument, IOUtils.toString(baos.toByteArray(), charset)));*/
				// For Update
				Map<String, Object> dataMap = jsonToMap(jobj);
				StringBuilder sbl = new StringBuilder("set");
				NameMap nameMap = new NameMap();
				ValueMap valueMap = new ValueMap();
				Set<String> keys = dataMap.keySet();
				Iterator<String> iterator = keys.iterator();

				for (int i = 0; i < dataMap.size(); i++) {
					String key = iterator.next();
					// create update expression:
					sbl.append(" #key" + i + "=:val" + i);
					// create name Map
					nameMap.with("#key" + i, key);
					// create value map
					valueMap.with(":val" + i, dataMap.get(key));

					if (i != dataMap.size() - 1) {
						sbl.append(",");
					}
				}

				UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey(hashKeyName, hashKeyValue, rangeKeyName, rangeKeyValue)
						.withUpdateExpression(sbl.toString()).withNameMap(nameMap).withValueMap(valueMap)
						.withReturnValues(ReturnValue.ALL_NEW);
				final DynamoDB dynamoDB2 = getDynamoDB();
				UpdateItemOutcome outcome = dynamoDB2.getTable(table).updateItem(updateItemSpec);
				outcome.getItem().toJSONPretty();
			}
			keysToFlowFileMap.put(new ItemKeys(hashKeyValue, rangeKeyValue), flowFile);
		}

		if (keysToFlowFileMap.isEmpty()) {
			return;
		}

		final DynamoDB dynamoDB = getDynamoDB();

		try {
		//	BatchWriteItemOutcome outcome = dynamoDB.batchWriteItem(tableWriteItems);

			//handleUnprocessedItems(session, keysToFlowFileMap, table, hashKeyName, hashKeyValueType, rangeKeyName,
				//	rangeKeyValueType, outcome);

			// Handle any remaining flowfiles
			for (FlowFile flowFile : keysToFlowFileMap.values()) {
				getLogger().debug("Successful posted items to dynamodb : " + table);
				session.transfer(flowFile, REL_SUCCESS);
			}
		} catch (AmazonServiceException exception) {
			getLogger().error("Could not process flowFiles due to service exception : " + exception.getMessage());
			List<FlowFile> failedFlowFiles = processServiceException(session, flowFiles, exception);
			session.transfer(failedFlowFiles, REL_FAILURE);
		} catch (AmazonClientException exception) {
			getLogger().error("Could not process flowFiles due to client exception : " + exception.getMessage());
			List<FlowFile> failedFlowFiles = processClientException(session, flowFiles, exception);
			session.transfer(failedFlowFiles, REL_FAILURE);
		} catch (Exception exception) {
			getLogger().error("Could not process flowFiles due to exception : " + exception.getMessage());
			List<FlowFile> failedFlowFiles = processException(session, flowFiles, exception);
			session.transfer(failedFlowFiles, REL_FAILURE);
		}
	}

	private boolean isDataValid(FlowFile flowFile, String jsonDocument) {
		return (flowFile.getSize() + jsonDocument.length()) < DYNAMODB_MAX_ITEM_SIZE;
	}

	/**
	 * {@inheritDoc}
	 */
	protected Map<String, AttributeValue> getRequestItem(WriteRequest writeRequest) {
		return writeRequest.getPutRequest().getItem();
	}

	private static Map<String, Object> jsonToMap(JSONObject jobj) {
		Map<String, Object> retMap = new HashMap<String, Object>();

		if (!jobj.isEmpty()) {
			retMap = toMap(jobj);
		}

		return retMap;
	}

	private static Map<String, Object> toMap(JSONObject object) {
		Map<String, Object> map = new HashMap<String, Object>();

		// Iterator<String> keysItr = object.keys();

		@SuppressWarnings("unchecked")
		Set<String> keySet = object.keySet();
		Iterator<String> keysItr = keySet.iterator();
		while (keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);

			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			map.put(key, value);
		}
		return map;
	}

	public static List<Object> toList(JSONArray array) {
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < array.size(); i++) {
			Object value = array.get(i);
			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			list.add(value);
		}
		return list;
	}
}